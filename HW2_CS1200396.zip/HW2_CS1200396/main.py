# Instructions to reproduce - change exec files path to asbolute paths, add permissions for exec files

import subprocess
import re
import time 

num_graphs = 0

gspan_executable = "/home/baadalvm/A2/gSpan-64"
fsg_executable = "/home/baadalvm/A2/pafi-1.0.1/Linux/fsg"
gaston_executable = "/home/baadalvm/A2/gaston-1.1/gaston"
# gaston_executable = "/home/dual/cs5200424/COL761/A2/gaston"

def convert_yeast_to_gSpan(input_file, output_file):
  """Converts the Yeast dataset to the format required by gSpan.

  Args:
    input_file: The path to the input file.
    output_file: The path to the output file.
  """

  # Open the input and output files.
  with open(input_file, "r") as f, open(output_file, "w") as g:
    # Write the header line.
    # g.write("t # N\n")
    global num_graphs
    # Iterate over the graphs in the input file.
    graph_id = 0
    vertex_id = 0
    #  create a map of vertex label strings to vertex label numbers
    vertex_map = {}
    curr_vertex_label = 0

    for line in f:
      if line.startswith("#"):
        # read the graph id after #
        graph_id = int(line.split('#')[1])
        # Start a new graph.
        # graph_id += 1
        num_graphs += 1
        vertex_id = 0
        # vertex_map = {}
        # curr_vertex_label = 0
        g.write(f"t # {graph_id}\n")
      else:
        # if it is empty line then continue
        if line == "\n":
          continue
          
        # else it is either a vertex label (a string) or an edge (a tuple of three elements (Source node, Destination Node, Edge label)).
        
        # check if it is a single vertex or an edge
        if len(line.split()) == 1:
          # now check if it is a vertex label (string) or a number
          if re.match(r"^[a-zA-Z]+$", line.split()[0]):
            # it is a vertex label
            #  check if vertex label is already present in the map
            label = line.split()[0]
            if label in vertex_map.keys():
              g.write(f"v {vertex_id} {vertex_map[label]}\n")
            else :
              # assign the curr_vertex_label to it and increment
              vertex_map[label] = curr_vertex_label
              curr_vertex_label+=1
              g.write(f"v {vertex_id} {vertex_map[label]}\n")

            # g.write(f"v {vertex_id} {line.split()[0]}\n")
            vertex_id += 1
          # # Vertex line write in the form 	"v M L"	means that the Mth vertex in this graph has label L,
          # g.write(f"v {vertex_id} {line.split()[0]}\n")
          # vertex_id += 1
          else:
             continue 
        elif len(line.split()) == 3:
          # Edge line write in the form 	"e P Q L" means that there is an edge connecting the Pth vertex with the 
			  # Qth vertex. The edge has label L.
          g.write(f"e {line.split()[0]} {line.split()[1]} {line.split()[2]}\n")
        
        # g.write(line)

  # Close the input and output files.
  f.close()
  g.close()

def convert_yeast_to_fsg(input_file, output_file):
  """Converts the Yeast dataset to the format required by FSG.

  Args:
    input_file: The path to the input file.
    output_file: The path to the output file.
  """

  # Open the input and output files.
  with open(input_file, "r") as f, open(output_file, "w") as g:
    # Iterate over the graphs in the input file.
    vertex_id = 0
    graph_id = 0
    for line in f:
      if line.startswith("#"):
        # read the graph id after #
        graph_id = int(line.split('#')[1])
        vertex_id = 0
        g.write(f"t # {graph_id}\n")
      else:
        # if it is empty line then continue
        if line == "\n":
          continue
          
        # else it is either a vertex label (a string) or an edge (a tuple of three elements (Source node, Destination Node, Edge label)).
        
        # check if it is a single vertex or an edge
        if len(line.split()) == 1:
          # now check if it is a vertex label (string) or a number
          if re.match(r"^[a-zA-Z]+$", line.split()[0]):
            # it is a vertex label
            g.write(f"v {vertex_id} {line.split()[0]}\n")
            vertex_id += 1
          # # Vertex line write in the form 	"v M L"	means that the Mth vertex in this graph has label L,
          # g.write(f"v {vertex_id} {line.split()[0]}\n")
          # vertex_id += 1
          else:
             continue 
        elif len(line.split()) == 3:
          # Edge line write in the form 	"e P Q L" means that there is an edge connecting the Pth vertex with the 
			  # Qth vertex. The edge has label L.
          g.write(f"u {line.split()[0]} {line.split()[1]} {line.split()[2]}\n")
        
        

  # Close the input and output files.
  f.close()
  g.close()

def convert_yeast_to_gaston(input_file, output_file):
  """Converts the Yeast dataset to the format required by gaston.

  Args:
    input_file: The path to the input file.
    output_file: The path to the output file.
  """

  # Open the input and output files.
  with open(input_file, "r") as f, open(output_file, "w") as g:
    # Write the header line.
    # g.write("t # N\n")

    # Iterate over the graphs in the input file.
    graph_id = 0
    vertex_id = 0
    #  create a map of vertex label strings to vertex label numbers
    vertex_map = {}
    curr_vertex_label = 0

    for line in f:
      if line.startswith("#"):
        # read the graph id after #
        graph_id = int(line.split('#')[1])
        # Start a new graph.
        # graph_id += 1
        vertex_id = 0
        # vertex_map = {}
        # curr_vertex_label = 0
        g.write(f"t # {graph_id}\n")
      else:
        # if it is empty line then continue
        if line == "\n":
          continue
          
        # else it is either a vertex label (a string) or an edge (a tuple of three elements (Source node, Destination Node, Edge label)).
        
        # check if it is a single vertex or an edge
        if len(line.split()) == 1:
          # now check if it is a vertex label (string) or a number
          if re.match(r"^[a-zA-Z]+$", line.split()[0]):
            # it is a vertex label
            #  check if vertex label is already present in the map
            label = line.split()[0]
            if label in vertex_map.keys():
              g.write(f"v {vertex_id} {vertex_map[label]}\n")
            else :
              # assign the curr_vertex_label to it and increment
              vertex_map[label] = curr_vertex_label
              curr_vertex_label+=1
              g.write(f"v {vertex_id} {vertex_map[label]}\n")

            # g.write(f"v {vertex_id} {line.split()[0]}\n")
            vertex_id += 1
          # # Vertex line write in the form 	"v M L"	means that the Mth vertex in this graph has label L,
          # g.write(f"v {vertex_id} {line.split()[0]}\n")
          # vertex_id += 1
          else:
             continue 
        elif len(line.split()) == 3:
          # Edge line write in the form 	"e P Q L" means that there is an edge connecting the Pth vertex with the 
			  # Qth vertex. The edge has label L.
          g.write(f"e {line.split()[0]} {line.split()[1]} {line.split()[2]}\n")
        
        # g.write(line)

  # Close the input and output files.
  f.close()
  g.close()

# Plot the running times of the three tools.
# import matplotlib.pyplot as plt



def run_gSpan(gspan_input_file, output_file, minSup):
    """Runs gSpan on the given input file and writes the output to the given output file.

    Args:
        input_file: The path to the input file.
        output_file: The path to the output file.
        minSup: The minimum support threshold.
    """

    # gSpan requires the input file to be in a specific format.
    # The input file should contain a list of graphs, where each graph is represented by a list of edges.
    # Each edge is represented by a tuple of three elements: (source node, destination node, edge label).

    
    # Run gSpan
    subprocess.run([gspan_executable, "-f", gspan_input_file, "-o", output_file, "-s", str(minSup)])
    # subprocess.run([gspan_executable, "-f", gspan_input_file, "-s", str(minSup)])


def run_FSG(fsg_input_file, output_file, minSup):
    """Runs FSG on the given input file and writes the output to the given output file.

    Args:
        input_file: The path to the input file.
        output_file: The path to the output file.
        minSup: The minimum support threshold.
    """

    # FSG requires the input file to be in a specific format.
    # The input file should contain a list of graphs, where each graph is represented by a list of nodes and a list of edges.
    # Each node is represented by a string.
    # Each edge is represented by a tuple of two elements: (source node, destination node).

    
    # Run FSG.
    #example input command is ./fsg -s 100.0 -pt test.g
    subprocess.run([fsg_executable,  "-s", str(minSup), fsg_input_file])
    


def run_Gaston(gaston_input_file, output_file, minSup):
    """Runs Gaston on the given input file and writes the output to the given output file.

    Args:
        input_file: The path to the input file.
        output_file: The path to the output file.
        minSup: The minimum support threshold.
    """

    # Gaston requires the input file to be in a specific format.
    # The input file should contain a list of graphs, where each graph is represented by a list of nodes and a list of edges.
    # Each node is represented by a string.
    # Each edge is represented by a tuple of three elements: (source node, destination node, edge label).

    # Run Gaston.
    subprocess.run([gaston_executable, str(minSup), gaston_input_file, output_file])


def main():
  # gSpan_file = "167.txt_graph"
  input_file = "167.txt_graph"

# convert the input file to the required format.
  gspan_input_file = f"{input_file}_gspan"
  convert_yeast_to_gSpan(input_file, gspan_input_file)

# convert the input file to the required format.
  fsg_input_file = f"{input_file}_fsg"
  convert_yeast_to_fsg(input_file, fsg_input_file)

# convert the input file to the required format.
  gaston_input_file = f"{input_file}_gaston"
  convert_yeast_to_gaston(input_file, gaston_input_file)

  minSup_values = [0.05, 0.1, 0.25, 0.5, 0.95]
  # reverse the list
  minSup_values.reverse()
# calculate the running times for each minSup value for each algorithm to plot the graph  
  running_times_gSpan = {}
  running_times_FSG = {}
  running_times_Gaston = {}

# open files for writing the runtimes for each minSup value for each algorithm
  gSpan_runtime_file = f"yeast_gSpan_running_times.txt"
  FSG_runtime_file = f"yeast_FSG_running_times.txt"
  Gaston_runtime_file = f"yeast_Gaston_running_times.txt"

  # minSup_values = [0.95]
  for minSup in minSup_values:
      
      start_time = time.time()
      gSpan_output_file = f"yeast_gSpan_output_{minSup}"
      print("Running gSpan with minSup: ", minSup)
      run_gSpan(gspan_input_file, gSpan_output_file, minSup )
      end_time = time.time()
      running_times_gSpan[minSup] = end_time - start_time
      # write into the runtime file
      with open(gSpan_runtime_file, "a") as f:
        f.write(f"{minSup} {end_time - start_time}\n")


      start_time = time.time()
      FSG_output_file = f"yeast_FSG_output_{minSup}"
      support = minSup * 100
      run_FSG(fsg_input_file, FSG_output_file, support )
      end_time = time.time()
      running_times_FSG[minSup] = end_time - start_time
      # write into the runtime file
      with open(FSG_runtime_file, "a") as f:
        f.write(f"{minSup} {end_time - start_time}\n")

      
      start_time = time.time()
      Gaston_output_file = f"yeast_Gaston_output_{minSup}"
      #  support is the number of graphs in the output file
      support = minSup * num_graphs
      # print("Number of Graphs: ", num_graphs)
      run_Gaston(gaston_input_file, Gaston_output_file, support )
      end_time = time.time()
      running_times_Gaston[minSup] = end_time - start_time
      # write into the runtime file
      with open(Gaston_runtime_file, "a") as f:
        f.write(f"{minSup} {end_time - start_time}\n")
      
  
  # Print the running times for each tool and minSup value
  print("gSpan Runtimes:")
  for min_support, runtime in running_times_gSpan.items():
      print(f"MinSup {min_support}: {runtime} seconds")

  print("FSG Runtimes:")
  for min_support, runtime in running_times_FSG.items():
      print(f"MinSup {min_support}: {runtime} seconds")

  print("Gaston Runtimes:")
  for min_support, runtime in running_times_Gaston.items():
      print(f"MinSup {min_support}: {runtime} seconds")

  # # write the runtimes to a file for plotting
  # with open("yeast_gSpan_running_times.txt", "w") as f:
  #   for min_support, runtime in running_times_gSpan.items():
  #     f.write(f"{min_support} {runtime}\n")
  # with open("yeast_FSG_running_times.txt", "w") as f:
  #   for min_support, runtime in running_times_FSG.items():
  #     f.write(f"{min_support} {runtime}\n")
  # with open("yeast_Gaston_running_times.txt", "w") as f:
  #   for min_support, runtime in running_times_Gaston.items():
  #     f.write(f"{min_support} {runtime}\n")
    
  

  # plt.figure( )
  # # Load the running times from the output files.
  # gSpan_running_times = []
  # FSG_running_times = []
  # Gaston_running_times = []
  # for minSup in minSup_values:
  #     gSpan_output_file = f"yeast_gSpan.output.{minSup}"
  #     FSG_output_file = f"yeast_FSG.output.{minSup}"
  #     Gaston_output_file = f"yeast_Gaston.output.{minSup}" 
  #     with open(gSpan_output_file, "r") as f:
  #         gSpan_running_times.append(float(f.readline().split()[2]))
  #     with open(FSG_output_file, "r") as f:
  #         FSG_running_times.append(float(f.readline().split()[2]))
  #     with open(Gaston_output_file, "r") as f:
  #         Gaston_running_times.append(float(f.readline().split()[2])  )
  # # Plot the running times.
  # plt.plot(minSup_values, gSpan_running_times, label="gSpan")
  # plt.plot(minSup_values, FSG_running_times, label="FSG")
  # plt.plot(minSup_values, Gaston_running_times, label="Gaston"  )
  # # Set the axis labels and title.
  # plt.xlabel("Minimum support threshold")
  # plt.ylabel("Running time (seconds)")
  # plt.title("Running times of gSpan, FSG, and Gaston on the Yeast dataset"  )
  # # Add a legend.
  # plt.legend( )
  # # Save the plot.
  # plt.savefig("yeast_running_times.png")


if __name__ == "__main__":
    main()