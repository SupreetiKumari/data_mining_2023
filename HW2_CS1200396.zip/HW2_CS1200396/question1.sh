#!/bin/bash

chmod +x gSpan-64
chmod +x gaston
chmod +x ./pafi-1.0.1/Linux/fsg

python3 main.py
