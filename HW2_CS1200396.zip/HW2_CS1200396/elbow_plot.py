import argparse
import numpy as np
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt

def read_file(input_file):
    dataset = []
    with open(input_file, 'r') as file:
        for line in file:
            curr = [float(n) for n in line.strip().split()]
            dataset.append(curr)
    return dataset

def generate_plot(dataset):
    euclidean = []
    for k in range(1, 16):
        model = KMeans(n_clusters=k).fit(dataset)
        euclidean.append(model.inertia_)
    return euclidean

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Elbow Plotting')

    parser.add_argument('dataset_file', type=str)
    parser.add_argument('output_file', type=str)

    args = parser.parse_args()

    dataset = read_file(args.dataset_file)
    dataset = np.array(dataset)

    euclidean = generate_plot(dataset)

    #with open("euclidean_error.txt", 'a') as f:
    #    f.write(args.dataset_file)
    #    f.write('\n')
    #    for i in range(1, 16):
    #        #print(euclidean[i-1], "-", i)
    #        f.write(str(euclidean[i-1]))
    #        f.write(' - ')
    #        f.write(str(i))
    #        f.write('\n')
    #    f.write("----------------------------------\n\n")

    plt.figure()
    plt.plot(list(range(1, 16)), euclidean, color='green')
    plt.scatter(list(range(1, 16)), euclidean, color='red')
    plt.xticks(list(range(1, 16)))
    plt.xlabel("Number of Clusters")
    plt.ylabel("Sum of Euclidean Distances")
    plt.title("Elbow Plot")
    plt.savefig(args.output_file)
