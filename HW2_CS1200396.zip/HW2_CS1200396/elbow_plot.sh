#!/bin/bash

module purge
module load pythonpackages/3.6.0/scikit-learn/0.21.2/gnu
module load pythonpackages/3.6.0/matplotlib/3.0.2/gnu
module load pythonpackages/3.6.0/numpy/1.16.1/gnu

python elbow_plot.py $1 $3
