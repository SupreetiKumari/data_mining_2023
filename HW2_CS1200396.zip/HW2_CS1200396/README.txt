Team Members:

Eshan Jain (CS5200424) - 33%
Goonjan Saha (CS1200494) - 33%
Supreeti Kumari (CS1200396) - 33%

Everybody has contributed equally.

---------------------------------------------

Files included:

All the code files for Q1 and Q2. Also includes the report pdf and the
executables for Q1.

---------------------------------------------

Running Instructions:

Question 1:
1)	Change the paths of the executable files mentioned in the variables of main.py -
        gspan_executable, fsg_executable and gaston_executable to absolute paths of the executable files corresponding to each of them.
2) Run the bash script that changes the permissions of the executabe and runs
the code -
        bash question1.sh

Question 2:
In the directory, use the same commands as mentioned in the assignment prompt – 
    bash elbow_plot.sh <dataset> <dimension> <output_plot_name>
