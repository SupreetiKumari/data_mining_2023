Team Members:

Eshan Jain (CS5200424) - 33%
Goonjan Saha (CS1200494) - 33%
Supreeti Kumari (CS1200396) - 33%

Everybody has contributed equally.



Files included:

All the code files for Q1 and Q2. Also includes the report pdf, the executables and the datafiles.



Running Instructions:

Question 1:
1)	Change the paths of the executable files in the variables - gspan_executable, fsg_executable and gaston_executable to absolute paths of the executable files corresponding to each of them. 
2)	If required change the permissions of these executable files using - chmod +x <path_to_exectuable_file>
3)	Run the following command after entering into the directory:
		python3 main.py

Question 2:
In this directory, use the commands as mentioned in the assignment prompt – 
bash elbow_plot.sh <dataset> <dimension> <output_plot_name>
