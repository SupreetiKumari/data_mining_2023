# gSpan Runtimes:
# MinSup 0.95: 2.5897326469421387 seconds
# MinSup 0.5: 4.559407949447632 seconds
# MinSup 0.25: 39.364195823669434 seconds
# MinSup 0.1: 220.08464932441711 seconds
# MinSup 0.05: 646.4819512367249 seconds
# FSG Runtimes:
# MinSup 0.95: 19.415409803390503 seconds
# MinSup 0.5: 114.52340650558472 seconds
# MinSup 0.25: 334.70654702186584 seconds
# MinSup 0.1: 1179.8815746307373 seconds
# MinSup 0.05: 3537.431936979294 seconds
# Gaston Runtimes:
# MinSup 0.95: 0.5218486785888672 seconds
# MinSup 0.5: 0.7597265243530273 seconds
# MinSup 0.25: 3.0517895221710205 seconds
# MinSup 0.1: 10.561837434768677 seconds
# MinSup 0.05: 24.522231578826904 seconds

# plot the runtimes
import matplotlib.pyplot as plt
import numpy as np

# Define the list of minimum support values (as percentages)
min_support_values = [5, 10, 25, 50, 95]

# Create dictionaries to store running times for each tool
gspan_runtimes = {5: 646.4819512367249, 10: 220.08464932441711, 25: 39.364195823669434, 50: 4.559407949447632, 95: 2.5897326469421387}
fsg_runtimes = {5: 3537.431936979294, 10: 1179.8815746307373, 25: 334.70654702186584, 50: 114.52340650558472, 95: 19.415409803390503}
gaston_runtimes = {5: 24.522231578826904, 10: 10.561837434768677, 25: 3.0517895221710205, 50: 0.7597265243530273, 95: 0.5218486785888672}

# Plot the runtimes
plt.plot(min_support_values, list(gspan_runtimes.values()), label="gSpan")
plt.plot(min_support_values, list(fsg_runtimes.values()), label="FSG")
plt.plot(min_support_values, list(gaston_runtimes.values()), label="Gaston")
plt.xlabel("Minimum Support (%)")
plt.ylabel("Runtime (seconds)")
plt.legend()
plt.title("Runtime Comparison")
plt.show()

#  save the plot as a PNG image
plt.savefig("runtimes.png")


