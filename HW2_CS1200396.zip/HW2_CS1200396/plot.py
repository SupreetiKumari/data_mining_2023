

# gSpan Runtimes:
# MinSup 0.95: 4.405317783355713 seconds
# MinSup 0.5: 83.31543469429016 seconds
# MinSup 0.25: 239.68206572532654 seconds
# MinSup 0.1: 951.1756656169891 seconds
# MinSup 0.05: 2826.0466549396515 seconds
# FSG Runtimes:
# MinSup 0.95: 19.46394181251526 seconds
# MinSup 0.5: 115.4920802116394 seconds
# MinSup 0.25: 337.0298571586609 seconds
# MinSup 0.1: 1189.379410982132 seconds
# MinSup 0.05: 3558.221461057663 seconds
# Gaston Runtimes:
# MinSup 0.95: 0.8025712966918945 seconds
# MinSup 0.5: 6.037379741668701 seconds
# MinSup 0.25: 12.751398086547852 seconds
# MinSup 0.1: 44.290858030319214 seconds
# MinSup 0.05: 116.92272162437439 seconds




# plot the runtimes
import matplotlib.pyplot as plt
import numpy as np

# Define the list of minimum support values (as percentages)
min_support_values = [5, 10, 25, 50, 95]

# Create dictionaries to store running times for each tool
gspan_runtimes = {5: 2826.0466549396515, 10: 951.1756656169891, 25: 239.68206572532654, 50: 83.31543469429016, 95: 4.405317783355713}
fsg_runtimes = {5: 3558.221461057663, 10: 1189.379410982132, 25: 337.0298571586609, 50: 115.4920802116394, 95: 19.46394181251526}
gaston_runtimes = {5: 116.92272162437439, 10: 44.290858030319214, 25: 12.751398086547852, 50: 6.037379741668701, 95: 0.8025712966918945}


# Plot the runtimes for each algorithm separately
plt.plot(min_support_values, list(gspan_runtimes.values()), label="gSpan")
plt.xlabel("Minimum Support (%)")
plt.ylabel("Runtime (seconds)")
plt.legend()
plt.title("gSpan Runtimes")
plt.show()

plt.plot(min_support_values, list(fsg_runtimes.values()), label="FSG")
plt.xlabel("Minimum Support (%)")
plt.ylabel("Runtime (seconds)")
plt.legend()
plt.title("FSG Runtimes")
plt.show()

plt.plot(min_support_values, list(gaston_runtimes.values()), label="Gaston")
plt.xlabel("Minimum Support (%)")
plt.ylabel("Runtime (seconds)")
plt.legend()
plt.title("Gaston Runtimes")
plt.show()



#plot all runtimes on the same plot
plt.plot(min_support_values, list(gspan_runtimes.values()), label="gSpan")
plt.plot(min_support_values, list(fsg_runtimes.values()), label="FSG")  
plt.plot(min_support_values, list(gaston_runtimes.values()), label="Gaston")
plt.xlabel("Minimum Support (%)")
plt.ylabel("Runtime (seconds)")
plt.legend()
plt.title("Runtimes")
plt.show()


# #  save the plot as a PNG image
# plt.savefig("runtimes.png")


